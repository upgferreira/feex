import React, { useState, useMemo } from 'react';
import { TrendingUp, DollarSign, ShoppingCart, BarChart2, Target, Receipt, PieChart, Table } from 'lucide-react';
import { useFileData } from '../hooks/useFileData';

// Category mapping for Mercado Livre (from original)
const ML_CATEGORY_MAP: Record<string, { categoriaPai: string; categoria: string; tipo: string }> = {
  "Cancelamento da tarifa de devolução por envio externo ou intermunicipal": { categoriaPai: "Outras receitas", categoria: "Cancelamentos de despesas", tipo: "Receita" },
  "Cancelamento da tarifa de manutenção da Minha página": { categoriaPai: "Outras receitas", categoria: "Cancelamentos de despesas", tipo: "Receita" },
  "Cancelamento da tarifa de venda": { categoriaPai: "Outras receitas", categoria: "Cancelamentos de despesas", tipo: "Receita" },
  "Cancelamento da tarifa por campanhas de publicidade - Product Ads": { categoriaPai: "Outras receitas", categoria: "Cancelamentos de despesas", tipo: "Receita" },
  "Cancelamento da tarifa por devolução": { categoriaPai: "Outras receitas", categoria: "Cancelamentos de despesas", tipo: "Receita" },
  "Cancelamento da tarifa por envio interno ao município": { categoriaPai: "Outras receitas", categoria: "Cancelamentos de despesas", tipo: "Receita" },
  "Estorno da tarifa de venda": { categoriaPai: "Outras receitas", categoria: "Estornos de despesas", tipo: "Receita" },
  "Estorno do custo de Mercado Envios": { categoriaPai: "Outras receitas", categoria: "Estornos de despesas", tipo: "Receita" },
  "Tarifa de devolução": { categoriaPai: "Despesas comerciais", categoria: "Fretes de devoluções", tipo: "Despesa" },
  "Tarifa de envio extra ou intermunicipal": { categoriaPai: "Despesas comerciais", categoria: "Fretes sobre vendas", tipo: "Despesa" },
  "Tarifa de envio interno à cidade": { categoriaPai: "Despesas comerciais", categoria: "Fretes de vendas", tipo: "Despesa" },
  "Tarifa de venda": { categoriaPai: "Deduções sobre vendas", categoria: "Taxas sobre vendas", tipo: "Despesa" },
  "Tarifa do Mercado Envios": { categoriaPai: "Despesas comerciais", categoria: "Fretes sobre vendas", tipo: "Despesa" },
  "Tarifas dos serviços do Mercado Pago": { categoriaPai: "Deduções sobre vendas", categoria: "Taxas sobre vendas", tipo: "Despesa" },
  "Taxas de parcelamento": { categoriaPai: "Deduções sobre vendas", categoria: "Taxas de parcelamento", tipo: "Despesa" },
  "Custo de gestão da venda": { categoriaPai: "Deduções sobre vendas", categoria: "Taxas sobre vendas", tipo: "Despesa" },
};

const CANAIS = ['AMAZON', 'MAGAZINE LUIZA', 'MERCADO LIVRE', 'SHEIN', 'SHOPEE'];

const DONUT_COLORS = ['#3B82F6','#EF4444','#10B981','#F59E0B','#8B5CF6','#EC4899','#06B6D4','#84CC16'];

function formatBRL(value: number) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
}

interface DadosProps {
  selectedCanal?: string;
}

export const Dados: React.FC<DadosProps> = ({ selectedCanal: externalCanal }) => {
  const { files, getAllChannelData } = useFileData();
  const [selectedCanal, setSelectedCanal] = useState<string>(externalCanal || 'TODOS');
  const [page, setPage] = useState(1);
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [colFilters, setColFilters] = useState<Record<string, string>>({});
  const [viewMode, setViewMode] = useState<'grafico' | 'tabela'>('grafico');
  const [dateFilter, setDateFilter] = useState<{ startDate: string; endDate: string }>({ startDate: '', endDate: '' });
  const ROWS_PER_PAGE = 100;

  // Sync with header canal filter
  React.useEffect(() => {
    if (externalCanal) setSelectedCanal(externalCanal);
  }, [externalCanal]);

  // Canal tabs
  const canalTabs = useMemo(() => ['TODOS', ...CANAIS.filter(c => getAllChannelData(c).length > 0)], [files, getAllChannelData]);

  // Raw data for selected canal
  const rawData = useMemo(() => {
    if (selectedCanal === 'TODOS') {
      return CANAIS.flatMap(c => getAllChannelData(c));
    }
    return getAllChannelData(selectedCanal);
  }, [selectedCanal, files, getAllChannelData]);

  // Stats calculation
  const stats = useMemo(() => {
    if (rawData.length === 0) return { vendas: 0, receita: 0, taxas: 0, lucro: 0, ticketMedio: 0, impostos: 0, lucroBruto: 0 };

    if (selectedCanal === 'MERCADO LIVRE') {
      const vendas = new Set(rawData.map((r: any) => r['Número da venda'])).size;
      const receita = rawData.reduce((acc: number, r: any) => acc + (Number(r['Valor da transação']) || 0), 0);
      const taxas = rawData.reduce((acc: number, r: any) => acc + (Number(r['Valor da tarifa']) || 0), 0);
      const lucro = receita - taxas;
      const ticketMedio = vendas > 0 ? receita / vendas : 0;
      const impostos = receita * 0.1;
      return { vendas, receita, taxas, lucro, ticketMedio, impostos, lucroBruto: lucro - impostos };
    }

    if (selectedCanal === 'TODOS') {
      let vendas = 0, receita = 0, taxas = 0;
      CANAIS.forEach(c => {
        const data = getAllChannelData(c);
        if (c === 'MERCADO LIVRE') {
          vendas += new Set(data.map((r: any) => r['Número da venda'])).size;
          receita += data.reduce((acc: number, r: any) => acc + (Number(r['Valor da transação']) || 0), 0);
          taxas += data.reduce((acc: number, r: any) => acc + (Number(r['Valor da tarifa']) || 0), 0);
        } else {
          vendas += data.length;
          receita += data.reduce((acc: number, r: any) => {
            const keys = Object.keys(r).filter(k => typeof r[k] === 'number' && r[k] > 0);
            return keys.length > 0 ? acc + (Number(r[keys[0]]) || 0) : acc;
          }, 0);
        }
      });
      const lucro = receita - taxas;
      const ticketMedio = vendas > 0 ? receita / vendas : 0;
      const impostos = receita * 0.1;
      return { vendas, receita, taxas, lucro, ticketMedio, impostos, lucroBruto: lucro - impostos };
    }

    // Other canais
    const vendas = rawData.length;
    const receita = rawData.reduce((acc: number, r: any) => {
      const keys = Object.keys(r).filter(k => typeof r[k] === 'number' && r[k] > 0);
      return keys.length > 0 ? acc + (Number(r[keys[0]]) || 0) : acc;
    }, 0);
    const lucro = receita;
    const ticketMedio = vendas > 0 ? receita / vendas : 0;
    const impostos = receita * 0.1;
    return { vendas, receita, taxas: 0, lucro, ticketMedio, impostos, lucroBruto: lucro - impostos };
  }, [rawData, selectedCanal, getAllChannelData]);

  // Pie chart data (categoria pai)
  const categoriaPaiData = useMemo(() => {
    if (selectedCanal !== 'TODOS' || rawData.length === 0) return [];
    const map: Record<string, number> = {};
    rawData.forEach((r: any) => {
      const cat = (r['CATEGORIA PAI']?.toString()) || 'Sem categoria pai';
      const val = Math.abs(Number(r.VALOR) || 0);
      map[cat] = (map[cat] || 0) + val;
    });
    const total = Object.values(map).reduce((a, b) => a + b, 0);
    return Object.entries(map)
      .map(([name, value]) => ({ name, value, percentage: total > 0 ? ((value / total) * 100).toFixed(1) : '0' }))
      .sort((a, b) => b.value - a.value).slice(0, 10);
  }, [rawData, selectedCanal]);

  // Pie chart data (categoria)
  const categoriaData = useMemo(() => {
    if (selectedCanal !== 'TODOS' || rawData.length === 0) return [];
    const map: Record<string, number> = {};
    rawData.forEach((r: any) => {
      const cat = (r.CATEGORIA?.toString()) || 'Sem categoria';
      const val = Math.abs(Number(r.VALOR) || 0);
      map[cat] = (map[cat] || 0) + val;
    });
    const total = Object.values(map).reduce((a, b) => a + b, 0);
    return Object.entries(map)
      .map(([name, value]) => ({ name, value, percentage: total > 0 ? ((value / total) * 100).toFixed(1) : '0' }))
      .sort((a, b) => b.value - a.value).slice(0, 10);
  }, [rawData, selectedCanal]);

  // Bar chart (receita por dia)
  const receitaDia = useMemo(() => {
    if (rawData.length === 0) return [];
    const map: Record<string, number> = {};
    rawData.forEach((r: any) => {
      const dateKey = Object.keys(r).find(k => k.toLowerCase().includes('data'));
      if (!dateKey) return;
      const d = r[dateKey];
      let dateStr = '';
      if (d instanceof Date) dateStr = d.toLocaleDateString('pt-BR');
      else if (typeof d === 'string') dateStr = d.slice(0, 10);
      if (!dateStr) return;
      const valKey = selectedCanal === 'MERCADO LIVRE' ? 'Valor da transação' : Object.keys(r).find(k => typeof r[k] === 'number' && r[k] > 0) || '';
      const val = Number(r[valKey]) || 0;
      map[dateStr] = (map[dateStr] || 0) + val;
    });
    return Object.entries(map).map(([data, receita]) => ({ data, receita })).sort((a, b) => a.data.localeCompare(b.data));
  }, [rawData, selectedCanal]);

  // Table columns
  const columns = useMemo(() => {
    if (rawData.length === 0) return [];
    return Object.keys(rawData[0]);
  }, [rawData]);

  // Column filter options
  const getColOptions = (col: string) => {
    const vals = rawData.map((r: any) => r[col]).filter(Boolean);
    return [...new Set(vals)].sort();
  };

  // Filtered + sorted + paginated data
  const filteredData = useMemo(() => {
    let data = [...rawData];

    // Date filter
    if (dateFilter.startDate || dateFilter.endDate) {
      data = data.filter((r: any) => {
        const dateKey = Object.keys(r).find(k => k.toLowerCase().includes('data'));
        if (!dateKey) return true;
        const d = r[dateKey];
        let dateStr = d instanceof Date ? d.toISOString().slice(0, 10) : String(d).slice(0, 10);
        if (dateFilter.startDate && dateStr < dateFilter.startDate) return false;
        if (dateFilter.endDate && dateStr > dateFilter.endDate) return false;
        return true;
      });
    }

    // Column filters
    Object.entries(colFilters).forEach(([col, val]) => {
      if (val) data = data.filter((r: any) => String(r[col]) === val);
    });

    // Sort
    if (sortCol) {
      data.sort((a: any, b: any) => {
        const va = a[sortCol], vb = b[sortCol];
        if (typeof va === 'number' && typeof vb === 'number') return sortDir === 'asc' ? va - vb : vb - va;
        return sortDir === 'asc' ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
      });
    }

    return data;
  }, [rawData, colFilters, sortCol, sortDir, dateFilter]);

  const totalPages = Math.ceil(filteredData.length / ROWS_PER_PAGE);
  const pageData = filteredData.slice((page - 1) * ROWS_PER_PAGE, page * ROWS_PER_PAGE);

  const handleSort = (col: string) => {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortCol(col); setSortDir('asc'); }
  };

  const setColFilter = (col: string, val: string) => {
    setColFilters(f => ({ ...f, [col]: val }));
    setPage(1);
  };

  const statCards = [
    { label: 'Vendas', value: stats.vendas.toLocaleString('pt-BR'), icon: <ShoppingCart className="h-6 w-6 text-blue-600" /> },
    { label: 'Ticket Médio', value: formatBRL(stats.ticketMedio), icon: <Target className="h-6 w-6 text-purple-600" /> },
    { label: 'Receita', value: formatBRL(stats.receita), icon: <DollarSign className="h-6 w-6 text-green-600" /> },
    { label: 'Taxas', value: formatBRL(stats.taxas), icon: <Receipt className="h-6 w-6 text-red-600" /> },
    { label: 'Lucro', value: formatBRL(stats.lucro), icon: <TrendingUp className="h-6 w-6 text-emerald-600" /> },
    { label: 'Impostos', value: formatBRL(stats.impostos), icon: <BarChart2 className="h-6 w-6 text-orange-600" /> },
    { label: 'Lucro Bruto', value: formatBRL(stats.lucroBruto), icon: <TrendingUp className="h-6 w-6 text-teal-600" /> },
  ];

  // Simple donut using SVG
  const Donut = ({ data, title }: { data: typeof categoriaPaiData; title: string }) => {
    if (data.length === 0) return null;
    const total = data.reduce((a, b) => a + b.value, 0);
    let cum = 0;
    const R = 80, cx = 100, cy = 100;
    const slices = data.map((d, i) => {
      const pct = d.value / total;
      const startAngle = cum * 2 * Math.PI - Math.PI / 2;
      cum += pct;
      const endAngle = cum * 2 * Math.PI - Math.PI / 2;
      const x1 = cx + R * Math.cos(startAngle), y1 = cy + R * Math.sin(startAngle);
      const x2 = cx + R * Math.cos(endAngle), y2 = cy + R * Math.sin(endAngle);
      const largeArc = pct > 0.5 ? 1 : 0;
      return { path: `M ${cx} ${cy} L ${x1} ${y1} A ${R} ${R} 0 ${largeArc} 1 ${x2} ${y2} Z`, color: DONUT_COLORS[i % DONUT_COLORS.length], ...d };
    });
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
        <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">{title}</h3>
        <div className="flex gap-6">
          <svg viewBox="0 0 200 200" className="w-32 h-32 flex-shrink-0">
            {slices.map((s, i) => <path key={i} d={s.path} fill={s.color} />)}
            <circle cx={cx} cy={cy} r={50} fill="currentColor" className="text-white dark:text-gray-800" />
          </svg>
          <div className="flex flex-col gap-1 text-xs overflow-auto max-h-32">
            {slices.map((s, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: s.color }} />
                <span className="text-gray-700 dark:text-gray-300 truncate max-w-[140px]">{s.name}</span>
                <span className="text-gray-500 ml-auto">{s.percentage}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  // Simple bar chart using divs
  const BarChartDiv = ({ data }: { data: typeof receitaDia }) => {
    if (data.length === 0) return null;
    const max = Math.max(...data.map(d => d.receita));
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
        <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Receita por Dia</h3>
        <div className="flex items-end gap-0.5 h-32 overflow-x-auto">
          {data.map((d, i) => (
            <div key={i} className="flex flex-col items-center gap-1 flex-shrink-0" style={{ minWidth: 20 }}>
              <div
                className="w-4 bg-blue-500 rounded-t"
                style={{ height: max > 0 ? `${(d.receita / max) * 100}%` : '4px' }}
                title={`${d.data}: ${formatBRL(d.receita)}`}
              />
            </div>
          ))}
        </div>
        <div className="flex justify-between text-xs text-gray-400 mt-1">
          <span>{data[0]?.data}</span>
          <span>{data[data.length - 1]?.data}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col">
      {/* Subheader */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-8">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Visualização de Dados</h2>
            <div className="flex items-center gap-1">
              {canalTabs.map(tab => (
                <button
                  key={tab}
                  onClick={() => { setSelectedCanal(tab); setPage(1); setColFilters({}); }}
                  className={`px-3 py-1 text-sm font-medium transition-colors duration-200 border-b-2 ${
                    selectedCanal === tab
                      ? 'text-blue-600 dark:text-blue-400 border-blue-600 dark:border-blue-400'
                      : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white border-transparent'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={dateFilter.startDate}
                onChange={e => setDateFilter(f => ({ ...f, startDate: e.target.value }))}
                className="px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
              <span className="text-xs text-gray-500">até</span>
              <input
                type="date"
                value={dateFilter.endDate}
                onChange={e => setDateFilter(f => ({ ...f, endDate: e.target.value }))}
                className="px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
              {(dateFilter.startDate || dateFilter.endDate) && (
                <button
                  onClick={() => setDateFilter({ startDate: '', endDate: '' })}
                  className="text-xs text-red-500 hover:text-red-700"
                >Limpar</button>
              )}
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setViewMode('grafico')}
                className={`p-1.5 rounded ${viewMode === 'grafico' ? 'bg-blue-100 dark:bg-blue-900 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
              >
                <PieChart className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('tabela')}
                className={`p-1.5 rounded ${viewMode === 'tabela' ? 'bg-blue-100 dark:bg-blue-900 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
              >
                <Table className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="flex gap-3 px-6 py-3 overflow-x-auto flex-shrink-0 bg-gray-50 dark:bg-gray-900">
        {statCards.map(card => (
          <div key={card.label} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 flex items-center flex-shrink-0 min-w-[140px]">
            <div className="flex-shrink-0">{card.icon}</div>
            <div className="ml-3">
              <p className="text-xs font-medium text-gray-500 dark:text-gray-400">{card.label}</p>
              <p className="text-lg font-semibold text-gray-900 dark:text-white">{card.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-auto px-6 py-4">
        {viewMode === 'grafico' ? (
          <div className="space-y-4">
            {selectedCanal === 'TODOS' && (
              <div className="grid grid-cols-2 gap-4">
                <Donut data={categoriaPaiData} title="Distribuição por Categoria Pai" />
                <Donut data={categoriaData} title="Distribuição por Categoria" />
              </div>
            )}
            <BarChartDiv data={receitaDia} />
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {/* Table */}
            <div className="flex-1 overflow-auto">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr>
                    {columns.map(col => (
                      <th key={col} className="text-left px-3 py-2 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider sticky top-0 bg-gray-50 dark:bg-gray-700 z-10">
                        <div className="space-y-1">
                          <div
                            className="flex items-center gap-1 cursor-pointer hover:text-gray-900 dark:hover:text-white"
                            onClick={() => handleSort(col)}
                          >
                            {col}
                            {sortCol === col && <span>{sortDir === 'asc' ? '↑' : '↓'}</span>}
                          </div>
                          <select
                            value={colFilters[col] || ''}
                            onChange={e => setColFilter(col, e.target.value)}
                            className="w-full px-1 py-0.5 text-xs border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                            onClick={e => e.stopPropagation()}
                          >
                            <option value="">Todos</option>
                            {getColOptions(col).slice(0, 50).map(v => (
                              <option key={String(v)} value={String(v)}>{String(v)}</option>
                            ))}
                          </select>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {pageData.map((row: any, i) => (
                    <tr key={i} className="hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700">
                      {columns.map(col => {
                        const val = row[col];
                        const display = val instanceof Date
                          ? val.toLocaleDateString('pt-BR')
                          : typeof val === 'number'
                            ? val.toLocaleString('pt-BR')
                            : String(val ?? '');
                        return (
                          <td key={col} className="px-3 py-2 text-gray-700 dark:text-gray-300 whitespace-nowrap max-w-[200px] truncate">
                            {display}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 py-2">
                <button onClick={() => setPage(1)} disabled={page === 1} className="px-2 py-1 text-xs rounded border disabled:opacity-40">«</button>
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-2 py-1 text-xs rounded border disabled:opacity-40">‹</button>
                <span className="text-xs text-gray-500">{page} / {totalPages}</span>
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-2 py-1 text-xs rounded border disabled:opacity-40">›</button>
                <button onClick={() => setPage(totalPages)} disabled={page === totalPages} className="px-2 py-1 text-xs rounded border disabled:opacity-40">»</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
